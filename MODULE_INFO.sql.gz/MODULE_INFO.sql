-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: sw_vulnerability_db
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `MODULE_INFO`
--

DROP TABLE IF EXISTS `MODULE_INFO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MODULE_INFO` (
  `SEQUENCE` int DEFAULT NULL,
  `R_ID` int DEFAULT NULL,
  `PATH_START` char(150) DEFAULT NULL,
  `MODULE_NAME` char(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MODULE_INFO`
--

LOCK TABLES `MODULE_INFO` WRITE;
/*!40000 ALTER TABLE `MODULE_INFO` DISABLE KEYS */;
INSERT INTO `MODULE_INFO` VALUES (500101,5,'','glibc'),(400101,4,'','apache'),(300101,3,'tools/','tools'),(300102,3,'xen/arch/','arch'),(300103,3,'','xen'),(100101,1,'content/','webpage_structure'),(100102,1,'parser/','webpage_structure'),(100201,1,'js/src/xpconnect','javascript_xpconnect'),(100202,1,'js/xpconnect/','javascript_xpconnect'),(100301,1,'js/src/vm/','javascript_extras'),(100302,1,'js/src/jit/','javascript_extras'),(100303,1,'js/src/ion/','javascript_extras'),(100321,1,'js/src/','javascript'),(100351,1,'js/','javascript_extras'),(100352,1,'js2/','javascript_extras'),(100501,1,'layout/','layout_rendering'),(100502,1,'image/','layout_rendering'),(100503,1,'gfx/','layout_rendering'),(100504,1,'gfx2/','layout_rendering'),(100505,1,'media/','layout_rendering'),(100601,1,'dom/','dom'),(100701,1,'security/','network'),(100702,1,'netwerk/','network'),(100801,1,'editor/','libraries'),(100802,1,'embedding/','libraries'),(100803,1,'extensions/','libraries'),(100804,1,'ipc/','libraries'),(100805,1,'modules/','libraries'),(100806,1,'intl/','libraries'),(100807,1,'mail/','libraries'),(100808,1,'mailnews/','libraries'),(100901,1,'toolkit/','toolkit'),(101001,1,'widget/','widget'),(190001,1,'','mozilla'),(200101,2,'arch/','arch'),(200202,2,'drivers/','driver_extra'),(200103,2,'fs/','fs'),(200104,2,'kernel/','kernel'),(200105,2,'net/','net'),(290001,2,'','linux'),(600101,6,'','tomcat'),(700101,7,'','derby');
/*!40000 ALTER TABLE `MODULE_INFO` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-30 23:00:01
